#include <iostream>
#include <cmath> 

using namespace std;
void con_2to10(int a);
void data_test()
{
	cout<<"Test the following values\n\n";
	cout<<"Binary : 11000101 ";
	con_2to10(11000101);
	cout<<"Binary : 0000 ";
	con_2to10(0000);
	cout<<"Binary : 01 ";
	con_2to10(01);
	cout<<"Binary : 10101010 ";
	con_2to10(10101010);
	cout<<"Binary : 111111 ";
	con_2to10(111111);
	cout<<"Binary : 10000000 ";
	con_2to10(10000000);
	cout<<"Binary : 1111100000 ";
	con_2to10(1111100000);
	cout<<"Binary : 123456(No a binary) ";
	con_2to10(123456);
}
void main()
{ 
	int onemore=1;
	while(onemore)
	{
	cout<<"Enter binary numbers (nonnegative integers only), and enter 2 to stop, and enter 3 to test test3 values\n";
	int a=0;
	cin>>a;
	if(a==2)
		exit(1);
	if(a==3)
		data_test();
	if(a>0&&a!=3)
	{
		cout<<"The binary is : "<<a<<" ";
con_2to10(a);		
	
	}}
	return;
}
void con_2to10(int a)
{
	double b=0,c=0,d=0;
   while(a!=0)
  { c=a%10;
   if(c==1||c==0)
   {
	   a=a/10;
	   	b+=c*pow((double)2,d++);
   }	  
   else
   {
	   cout<<"your enter not a binary\n";
	   return;   
   }
   }
   cout<<"The Decimal is: "<<b<<endl;
}