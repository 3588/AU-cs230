#include <iostream>
#include <link.h>
using namespace std;

template<class NodeType>



bool 