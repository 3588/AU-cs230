#ifdef link_h
#define link_h
class 
{
public:
	void Printlist();
	bool IsEmpty();
protected:
private:
};
#endif