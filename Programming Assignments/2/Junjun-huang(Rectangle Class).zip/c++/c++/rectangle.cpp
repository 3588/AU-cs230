#include <iostream>
#include"rectangle.h"
using namespace std;

bool Rectangle::CheckInput()
{
	//x1y1  x2y2
	//
	//x3y3 x4y4
	if (x1==x3&&y1==y2&&x2==x4&&y3==y4)
	{
		return false;
	}
	else
	{
		return true;
	}
}
void Rectangle::GetData()
{
	cout<<"x1 : "<<x1<<" y1 : "<<y1<<" x2 : "<<x2<<" y2 : "<<y2<<" x3 : "<<x3<<" y3 : "<<y3<<" x4 : "<<x4<<" y4 : "<<y4<<endl;
}
void Rectangle::SetData(int gx1,int gy1, int gx2, int gy2, int gx3, int gy3,int gx4, int gy4)
{
	x1=gx1;
	y1=gy1;
	x2=gx2;
	y2=gy2;
	x3=gx3;
	y3=gy3;
	x4=gx4;
	y4=gy4;
}
bool Rectangle::Getlarger()
{
	if (y1-y3>x2-x1)
	{
		return true;
	} 
	else
	{
		return false;//square or vertical
	}
}
void Rectangle::GetDataLength(char c)
{
	cout<<"Length is:";
	if (c=='c')
	{
		cout<<y1-y3<<endl;
	} 
	if(c=='v')
	{
		cout<<x2-x1<<endl;
	}
}
void Rectangle::GetDataWidth(char c)
{
	cout<<"Width is:";
		if (c=='c')
		{
			cout<<x2-x1<<endl;
		} 
		if(c=='v')
		{
			cout<<y1-y3<<endl;
		}
}
void Rectangle::GetDataPerimeter()
{
	cout<<"Perimeter is: "<<2*(x2-x1)+2*(y1-y3)<<endl;
}
void Rectangle::GetDataArea()
{
	cout<<"Area is: "<<(x2-x1)*(y1-y3)<<endl;
}
bool Rectangle::IfDataSquare()
{
    if((x2-x1)==(y1-y3))
    {
        return true;
    }
    else
    {
        return false;
    }
}
void Rectangle::GetDataDraw(char type)
{
    if(type=='f')
    {
        for(int i=0;i<y1-y3;i++)
        { 
            for(int j=0;j<x2-x1;j++)
            {
                cout<<"* ";
            }
            cout<<endl;
        }
    }
    if(type=='p')
    {
         for(int i=0;i<y1-y3;i++)
        { 
            if(i==0||i==y1-y3-1)
            {
                for(int t=0;t<x2-x1;t++)
                    cout<<"* ";
            }
            else
            {
                cout<<"* ";
                for(int j=0;j<x2-x1-2;j++)
            {
                cout<<"  ";
            }
                cout<<"*";
            }
            
            cout<<endl;
        }
    }
}