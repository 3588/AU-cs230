  #include <iostream>
#include"rectangle.h"

using namespace std;
 
void UserMenu(int &t)
{
    int choose;
    do{
    cout<<"User Menu\n1.Length\n2.Width,\n3,Perimeter\n4.Area\n5.Square\n6.Fill-character\n7.Perimeter-character\n8.Exit\n";
    cin>>choose;
    if(choose<1||choose>8)
        choose=0;
    }while(choose==0);
    t=choose;
}
bool check(int t)
{
    if(t<21&&t>0)
        return false;
    else
        return true;
}
void Input(Rectangle &r1)
{
    int x[4],y[4],onemore=0;
    char tt;
    do{
       onemore=0;
    cout<<"Enter four pairs of numbers. EX:x,y\n";
    for(int i=0;i<4;i++)
    { 
        cin>>x[i]>>tt>>y[i];
    }
     for(int i=0;i<4;i++)
    { 
         if(check(x[i])||check(y[i]))
         {
          cout<<"Enter wrong: "<<i<<endl;
         onemore=1;
         }
    }
    r1.SetData(x[0],y[0],x[1],y[1],x[2],y[2],x[3],y[3]);
    r1.GetData();
    if(r1.CheckInput())
    {
        cout<<"Your enter not a rectangle\n";
        onemore=1;
    }
    }while(onemore);
}         

int main()
{
    
	Rectangle r1;
	//r1.SetData(2,10,9,10,2,3,9,3);
        r1.SetData(2,10,15,10,2,3,15,3);
	r1.GetData();
	if (r1.Getlarger())
	{
		r1.GetDataLength('c');//crosswise
		r1.GetDataWidth('c');//crosswise
	} 
	else
	{
		r1.GetDataLength('v');//vertical
		r1.GetDataWidth('v');//vertical
	}
	r1.GetDataPerimeter();
	r1.GetDataArea();
        if(r1.IfDataSquare())
        {cout<<"it is a square\n";}
        r1.GetDataDraw('f');
        
        
        //main
        Input(r1);
        int choose=0,onemore=1;
        do{
        UserMenu(choose);
        if(choose==1)
        {
            if (r1.Getlarger())
	{
		r1.GetDataLength('c');//crosswise
	} 
	else
	{
		r1.GetDataLength('v');//vertical
	}
        }
        if(choose==2)
        {
            if (r1.Getlarger())
	{
		r1.GetDataWidth('c');//crosswise
	} 
	else
	{
		r1.GetDataWidth('v');//vertical
	}
        }
        if(choose==3)
        {
            r1.GetDataPerimeter();
        }
        if(choose==4)
        {
            r1.GetDataArea();
        }
        if(choose==5)
        {
            if(r1.IfDataSquare())
                {cout<<"it is a square\n";}
            else
                {cout<<"it isn't a square\n";}
        }
        if(choose==6)
        {r1.GetDataDraw('f');}
        if(choose==7)
        {r1.GetDataDraw('p');}
        if(choose==8)
        {onemore=0;}
        }while(onemore);
	return 0;
}