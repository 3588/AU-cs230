#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>
using namespace std;
void Word(int);
bool GetFile(ifstream&);
struct Data 
{ 
	string name; 
	double vote; 
}; 
int main()
{
	ifstream in1,in2;
	if (GetFile(in1))//first time read the file,get the total for data
	{
		int total=1;
		while (!in1.eof())
		{
			char t1;
			in1.get(t1);
			if (t1=='\n')
			{
				in1.get(t1);
				if ((t1>'a'&&t1<'z')||(t1>'A'&&t1<'Z'))
				{
					total++;
				}	

			}
		
			
		}
//get total end
	
		in1.close();
	//start get date from file
	Data *votedata = new Data[total];
	int TotalVots=0;
	if (GetFile(in2))//open file
	{
		for (int i=0;i<total;i++)
			in2>>votedata[i].name>>votedata[i].vote;
		
		for (int i=0;i<total;i++)
			TotalVots=TotalVots+votedata[i].vote;
	}
	//dispaly
	Word(2);

	for (int i=0;i<total;i++)
	{
		double t;
		
		t=(votedata[i].vote*100)/TotalVots;
		int t1=votedata[i].vote;
		cout.setf(ios::fixed);
		cout.setf(ios::showpoint);
		cout<<setiosflags(ios::left)<<setw(20)<<votedata[i].name<<setw(20)<<t1<<setprecision(2)<<t<<endl;
	}
	cout<<setiosflags(ios::left)<<setw(20)<<"Total"<<setw(20)<<TotalVots<<"100.00"<<endl;
	int winner=0;
	for (int i=0;i<total-1;i++)
	{
		if (votedata[winner].vote<votedata[i+1].vote)
			winner=i+1;
	}
	Word(3);
	cout<<votedata[winner].name<<" .\n";
	

	}

	return 0;
}
bool GetFile(ifstream &in)
{
	in.open("input.txt");
	if (in.fail())
	{
		Word(1);
		return false;
	}
	return true;
}
void Word(int t)
{
	switch (t) {
  case 1:
	  cout << "Can't open input file.Please check the file name(input.txt)\n";
	  break;
  case 2:
	  cout << "Candidate	Votes Received		Percent of Total Votes\n";
	  break;
  case 3:
	  cout << "The Winner of the Election is ";
	  break;
  default:
	  cout << "value of x unknown";
	}
}
