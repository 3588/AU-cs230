#include "PrivatelyDerivedStack.h"

using namespace std;

int main()
{
	PrivatelyDerivedStack<int> intStack;

	for( int i=0 ; i <=10 ; i++)
		intStack.push( i);

	cout << "Stack contents: " << endl;
	intStack.printStack();

	int x;
	intStack.peek( x);
	cout << "\nStack Top is: " << x << endl;

	//intStack.insertAtBack( 100000);

	cout << "\nStack contents after the peek operation: " << endl;
	intStack.printStack();

	return 0;
}