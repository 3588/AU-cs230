#ifndef STACK_ARRAY_H
#define STACK_ARRAY_H

#include <iostream>
#include <cassert>

using namespace std;

template <class Type>
class StackType
{
public:
	StackType( int size = 100);
	void initializeStack();
	bool isStackEmpty();
	bool isStackFull();
	bool peek( Type & );
	bool push( const Type & );
	bool pop( Type & );
	void printStack();
	void getStackSize( int & );
	void getStackMaxSize( int & );
	~StackType( );

private: 
	Type * stack;
	int stackTop;
	int maxStackSize;
}; 

template <class Type>
StackType<Type>::StackType( int size )
{
	if( size <= 0)
	{
		cerr << "Invalid stack size. Default size of 100 is used." << endl;
		maxStackSize = 100;
	}
	else
		maxStackSize = size;
		
	stack = new Type[maxStackSize];
	assert( stack != NULL);
	stackTop = 0;
}

template <class Type>
StackType<Type>::~StackType()
{
	delete [] stack;
}

template <class Type>
void StackType<Type>::initializeStack()
{
	stackTop = 0;

	return;
}

template <class Type>
bool StackType<Type>::isStackEmpty( )
{
	return (stackTop == 0);
}

template <class Type>
bool StackType<Type>::isStackFull( )
{
	return (stackTop == maxStackSize);
}

template <class Type>
bool StackType<Type>::peek( Type & item)
{
	if( !isStackEmpty())
	{
		item = stack[stackTop];
		return true;
	}
	else
	{
		cerr << "Stack is empty. Cannot peek at an empty stack." << endl;
		return false;
	}
}

template <class Type>
bool StackType<Type>::push( const Type & newItem)
{
	if( isStackEmpty())
	{
		stack[stackTop] = newItem;
		stackTop++;
		return true;
	}

	if( !isStackFull())
	{
		stack[stackTop] = newItem;
		stackTop++;
		return true;
	}
	else
	{
		cerr << "Stack is full. Cannot add to a full stack." << endl;
		return false;
	}
}

template <class Type>
bool StackType<Type>::pop( Type & item)
{
	if( !isStackEmpty())
	{
		item = stack[stackTop];
		stackTop--;
		return true;
	}
	else
	{
		cerr << "Stack is empty. Cannot retrieve from an empty stack." << endl;
		return false;
	}
}

template <class Type>
void StackType<Type>::printStack()
{
	if( !isStackEmpty())
		for( int i = 0 ; i < stackTop ; i++)
			cout << stack[i] << endl;
	else
		cout << "Stack is empty. Cannot print an empty stack." << endl;

	return;
}

template <class Type>
void StackType<Type>::getStackSize( int & size)
{
	size = stackTop;
	return;
}

template <class Type>
void StackType<Type>::getStackMaxSize( int & maxSize)
{
	maxSize = maxStackSize;
	return;
}

#endif;