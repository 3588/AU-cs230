#include <iostream>
#include "StackType.h"

using namespace std;

int main()
{
	StackType<int> intStack( 20);

	for( int i = 0 ; i < 22 ; i++)
		intStack.push( i*2);

	intStack.printStack();

	return 0;
}