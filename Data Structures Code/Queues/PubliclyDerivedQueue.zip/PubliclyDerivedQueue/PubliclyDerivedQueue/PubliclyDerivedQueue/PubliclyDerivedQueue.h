#ifndef PUBLICLY_DERIVED_QUEUE_H
#define PUBLICLY_DERIVED_QUEUE_H

#include "LinkedList.h"

template <class NodeType>
class PubliclyDerivedQueue : public LinkedList<NodeType>
{
public:
	void resetQueue() 
			{ resetList(); return; }
	bool isQueueEmpty() 
			{ return isListEmpty(); }
	bool peekAtQueueFront( NodeType & value) 
			{ return peekAtFront( value); }
	bool peekAtQueueRear( NodeType & value) 
			{ return peekAtBack( value); }
	bool enQueue( const NodeType & value )
			{ return insertAtBack( value); }
	bool deQueue( NodeType & value)
			{ return removeFromFront( value); }
	void printQueue()
			{ printList(); return; }
	void getQueueSize( int & size)
			{ size = getListLength(); return; }
};

#endif;