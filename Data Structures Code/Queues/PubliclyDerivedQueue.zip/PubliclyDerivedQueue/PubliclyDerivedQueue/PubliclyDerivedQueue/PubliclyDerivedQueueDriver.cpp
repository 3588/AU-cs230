#include <iostream>
#include <cassert>
#include "PubliclyDerivedQueue.h"

using namespace std;

int main()
{
	PubliclyDerivedQueue<int> q;

	for( int i=1 ; i <=5 ; i++)
		q.enQueue( i);

	cout << "Queue contents: " << endl;
	q.printQueue();

	int x;
	q.peekAtQueueFront( x);
	cout << "\nQueue Front is: " << x << endl;

	q.insertAtFront( 100000);

	cout << "\nQueue contents after illegal operation: " << endl;
	q.printQueue();

	return 0;
}