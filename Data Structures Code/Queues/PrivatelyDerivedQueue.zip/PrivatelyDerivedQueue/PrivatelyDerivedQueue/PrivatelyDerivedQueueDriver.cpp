#include <iostream>
#include <cassert>
#include "PrivatelyDerivedQueue.h"

using namespace std;

int main()
{
	PrivatelyDerivedQueue<int> q;

	for( int i=1 ; i <=5 ; i++)
		q.enQueue( i);

	cout << "Queue contents: " << endl;
	q.printQueue();

	int x;
	q.peekAtQueueFront( x);
	cout << "\nQueue Front is: " << x << endl;

	//q.insertAtFront( 100000);

	//cout << "\nQueue contents after illegal operation: " << endl;
	q.printQueue();

	return 0;
}