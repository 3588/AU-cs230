#ifndef ARRAY_QUEUE_H
#define ARRAY_QUEUE_H

template <class Type>
class ArrayQueue
{
public:
	ArrayQueue( int = 100);
	bool isQueueEmpty();
	bool isQueueFull();
	bool enQueue( const Type & );
	bool deQueue( Type & );
	bool peekAtQueueFront( Type & );
	bool peekAtQueueBack( Type & );
	void getQueueSize( int & );
	void getQueueMaxSize( int & );
	void printQueue();
	void resetQueue();
	~ArrayQueue();
private:
	Type * queue;
	int queueFront;
	int queueRear;
	int count;
	int maxQueueSize;
};

template <class Type>
ArrayQueue<Type>::ArrayQueue( int size)
{
	if( size <= 0)
	{
		cerr << "Invalid queue size. Default size of 100 is used." << endl;
		maxQueueSize = 100;
	}
	else
		maxQueueSize = size;
		
	queue = new Type[maxQueueSize];
	assert( queue != NULL);
	count = 0;
	queueFront = -1;
	queueRear = -1;
}

template <class Type>
ArrayQueue<Type>::~ArrayQueue()
{
	delete [] queue;
}

template <class Type>
void ArrayQueue<Type>::resetQueue()
{
	count = 0;
	queueFront = -1;
	queueRear = -1;
}

template <class Type>
void ArrayQueue<Type>::printQueue()
{
	if( isQueueEmpty())
	{
		cout << "Queue is empty." << endl;
		return;
	}

	if( queueFront <= queueRear)
		for( int i=queueFront+1 ; i <= queueRear ; i++)
			cout << queue[i] << endl;
	else
	{
		for( int i = queueFront+1 ; i < maxQueueSize ; i++)
			cout << queue[i] << endl;
		cout << "Going around the circular array" << endl;
		for( int i = 0 ; i <= queueRear ; i++)
			cout << queue[i] << endl;
	}

	return;
}

template <class Type>
void ArrayQueue<Type>::getQueueSize( int & size )
{
	size = count;
	return;
}

template <class Type>
void ArrayQueue<Type>::getQueueMaxSize( int & size )
{
	size = queueMaxSize;
	return;
}

template <class Type>
bool ArrayQueue<Type>::peekAtQueueFront( Type &  item)
{
	if( !isQueueEmpty())
	{
		item = queue[queueFront];
		return true;
	}
	else
	{
		cerr << "Queue is empty. Cannot peek at an empty queue." << endl;
		return false;
	}
}

template <class Type>
bool ArrayQueue<Type>::peekAtQueueBack( Type &  item)
{
	if( !isQueueEmpty())
	{
		item = queue[queueBack];
		return true;
	}
	else
	{
		cerr << "Queue is empty. Cannot peek at an empty queue." << endl;
		return false;
	}
}

template <class Type>
bool ArrayQueue<Type>::isQueueEmpty( )
{
	return (count == 0);
}

template <class Type>
bool ArrayQueue<Type>::isQueueFull( )
{
	return (count == maxQueueSize);
}

template <class Type>
bool ArrayQueue<Type>::enQueue( const Type & newItem)
{
	if( !isQueueFull())
	{
		queueRear = (queueRear + 1) % maxQueueSize;
		queue[queueRear] = newItem;
		count++;
		return true;
	}
	else
	{
		cerr << "Queue is full. Cannot add to a full queue." << endl;
		return false;
	}
}

template <class Type>
bool ArrayQueue<Type>::deQueue( Type & item)
{
	if( !isQueueEmpty())
	{
		queueFront = (queueFront + 1) % maxQueueSize;
		item = queue[queueFront];
		count--;
		return true;
	}
	else
	{
		cerr << "Queue is empty. Cannot retrieve from an empty queue." << endl;
		return false;
	}
}
#endif;