#include <iostream>
#include <cassert>
#include "ArrayQueue.h"

using namespace std;

int main()
{
	int i, x;
	ArrayQueue<int> q;

	for( i = 1 ; i <= 100 ; i++)
		q.enQueue( i);	

	for( i = 1 ; i <= 10 ; i++)
	{
		q.deQueue( x);
		cout << "X = " << x << endl;
	}

	q.enQueue( 1000);
	q.enQueue( 2000);
	q.enQueue( 3000);

	q.printQueue();

	return 0;
}