#ifndef QUEUE_COMPOSITION_H
#define QUEUE_COMPOSITION_H

#include "LinkedList.h"

template <class NodeType>
class ComposedQueue
{
public:
	void resetQueue() 
			{ queueList.resetList(); return; }
	bool isQueueEmpty() 
			{ return queueList.isListEmpty(); }
	bool peekAtQueueFront( NodeType & value) 
			{ return queueList.peekAtFront( value); }
	bool peekAtQueueRear( NodeType & value) 
			{ return queueList.peekAtBack( value); }
	bool enQueue( const NodeType & value )
			{ return queueList.insertAtBack( value); }
	bool deQueue( NodeType & value)
			{ return queueList.removeFromFront( value); }
	void printQueue()
			{ queueList.printList(); return; }
	void getQueueSize( int & size)
			{ size = queueList.getListLength(); return; }
private:
	LinkedList<NodeType> queueList;
};

#endif;