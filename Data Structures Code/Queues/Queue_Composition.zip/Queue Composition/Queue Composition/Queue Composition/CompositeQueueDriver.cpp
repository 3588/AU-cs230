#include "CompositeQueue.h"

int main()
{
	ComposedQueue<int> compQ;

	for( int i = 0 ; i <= 15 ; i += 2)
		compQ.enQueue( i);

	cout << "Queue after enqueue: " << endl;
	compQ.printQueue();

	int x;
	compQ.peekAtQueueFront( x);
	cout << "First queue element: X = " << x << endl;

	compQ.peekAtQueueRear( x);
	cout << "Last queue element: X = " << x << endl;

	for( int i = 0 ; i <= 10 ; i += 2)
		compQ.deQueue( i);

	cout << "Queue after dequeue: " << endl;
	compQ.printQueue();

	return 0;
}