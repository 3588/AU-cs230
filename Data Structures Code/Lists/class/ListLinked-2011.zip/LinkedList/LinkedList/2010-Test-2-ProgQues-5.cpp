#include <iostream>
#include "LinkedList.h"

using namespace std;

int main()
{
	int x;
	LinkedList<int> L;

	L.printList();
	cout << endl;

	// Testing functions insertAtFront and insertAtBack
	L.resetList();
	for( int i=0 ; i<=10 ; i++)
		if( i%2 == 0)
			L.insertAtFront( i);
        else
        	L.insertAtBack( i);
	L.printList();

	// Testing functions removeFront and removeBack
	for( int i=1 ; i<=2 ; i++)
	{
		L.removeFromFront( x);
		L.removeFromBack( x);
	}
	cout << "\nThe list is: " << endl;
	L.printList();

	// Testing functions modifyFront and modifyBack
	L.modifyElementAtFront(50);
	L.modifyElementAtBack(101);
	cout << "\nThe new list is: " << endl;
	L.printList();

	// Testing functions retrieveFromFront and retrieveFromBack
	L.retrieveFromFront( x);
	cout << "\nElement at Front is: "	<< x << endl;
	L.retrieveFromBack( x);
	cout << "Element at Back is: " << x << endl;
	cout << "\nThe list is: " << endl;
	L.printList();

	// Testing function getNodeCount
	x = L.getNodeCount();
	cout << "\nThere are " << x << " nodes in the list." << endl;
	cout << "\nDestroying the list..." << endl;
	L.resetList();
	x = L.getNodeCount();
	cout << "\nThere are " << x << " nodes in the list." << endl;

	// Testing function isListEmpty
	for( int i=0 ; i<=10 ; i++)
		L.insertAtFront( i);
	cout << "\nThe list is: " << endl;
	L.printList();
	cout << "\nThe list in reverse order is: " << endl;
	L.printListInReverse();
	while( !L.isListEmpty())
		L.removeFromBack( x);
	cout << "\nThe list is: " << endl;
	L.printList();
	cout << "\nThe list in reverse order is: " << endl;
	L.printListInReverse();

	return 0;
}








