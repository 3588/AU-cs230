#include <iostream>
#include "Complex.h"

using namespace std;

int main()
{
	double a, b;
	ComplexType num1;
	ComplexType num2( 2, 3);



	return 0;
}