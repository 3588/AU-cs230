#include <iostream>
#include <vector>
using namespace std;
template <class elemType>
void reversVector(vector<elemType> &list)
{
	vector<int> Tlist;
	while (!list.empty())
	{
		int Loca=list.size()-1;
		Tlist.push_back(list[Loca]);
		list.pop_back();
	}

	list=Tlist;

}
template <class elemType>
void dispaly(vector<elemType> &list)
{
	cout<<"{";
	for (int i=0;i<list.size();i++)
	{
		if(i==list.size()-1)
			cout<<list[i];
		else
			cout<<list[i]<<",";
	}
	cout<<"}"<<endl;
}
int main()
{
	int intArray[4]={4,8,2,5};
	vector<int> veclist(intArray,intArray+4);
	reversVector(veclist);
	dispaly(veclist);

	int intArray1[20]={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20};
	vector<int> veclist1(intArray1,intArray1+20);
	reversVector(veclist1);
	dispaly(veclist1);
	return 0;

}